﻿# pragma warning disable

using UcakRezervasyon.Models;
using UcakRezervasyon.Control_Data;
using Microsoft.EntityFrameworkCore;

namespace UcakRezervasyon
{
    public partial class DBContext : DbContext
    {
        public virtual DbSet<ModelUcak> Ucaks { get; set; }
        public virtual DbSet<ModelLocation> Locations { get; set; }
        public virtual DbSet<ModelRezervasyon> Rezervasyons { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite($"Data Source={DB.DBPath}");
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ModelUcak>(entity =>
            {
                entity.ToTable("Ucak");
                entity.HasKey(e => e.IdUcak);
                entity.Property(e => e.UcakModel).HasColumnType("TEXT");
                entity.Property(e => e.UcakBrand).HasColumnType("TEXT");
                entity.Property(e => e.UcakSerialNo).HasColumnType("TEXT");
                entity.Property(e => e.UcakSeatCapacity).HasColumnType("INTEGER");
            });

            modelBuilder.Entity<ModelLocation>(entity =>
            {
                entity.ToTable("Location");
                entity.HasKey(e => e.IdLocation);
                entity.Property(e => e.Country).HasColumnType("TEXT");
                entity.Property(e => e.City).HasColumnType("TEXT");
                entity.Property(e => e.Airport).HasColumnType("TEXT");
                entity.Property(e => e.ActivePassive).HasColumnType("BOOLEAN");
            });

            modelBuilder.Entity<ModelRezervasyon>(entity =>
            {
                entity.ToTable("Rezervasyon");
                entity.HasKey(e => e.IdRezervasyon);
                entity.Property(e => e.UcakId).HasColumnType("INTEGER");
                entity.Property(e => e.LocationId).HasColumnType("INTEGER");
                entity.Property(e => e.Date).HasColumnType("TEXT");
                entity.Property(e => e.CustomerIDNo).HasColumnType("TEXT");
                entity.Property(e => e.CustomerName).HasColumnType("TEXT");
                entity.Property(e => e.CustomerSurname).HasColumnType("TEXT");
                entity.Property(e => e.CustomerGender).HasColumnType("TEXT");
                entity.Property(e => e.SeatNo).HasColumnType("TEXT");
            });

            base.OnModelCreating(modelBuilder);
        }
    }
}
