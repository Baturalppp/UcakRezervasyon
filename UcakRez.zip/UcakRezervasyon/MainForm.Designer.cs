﻿using System.Windows.Forms;

namespace UcakRezervasyon
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            tabControl1 = new TabControl();
            tabUcak = new TabPage();
            btnDeleteUcak = new Button();
            btnUpdateUcak = new Button();
            btnSaveUcak = new Button();
            dataGridViewUcak = new DataGridView();
            txtUcakSeatCapacity = new MaskedTextBox();
            txtUcakSerialNo = new TextBox();
            txtUcakBrand = new TextBox();
            txtUcakModel = new TextBox();
            lblUcakCapacity = new Label();
            lblUcakSerialNo = new Label();
            lblUcakBrand = new Label();
            lblUcakModel = new Label();
            tabLocation = new TabPage();
            btnDeleteLocation = new Button();
            btnUpdateLocation = new Button();
            comboActivePassive = new ComboBox();
            btnSaveLocation = new Button();
            comboAirport = new ComboBox();
            comboCity = new ComboBox();
            comboCountry = new ComboBox();
            dataGridViewLocation = new DataGridView();
            lblActivePassive = new Label();
            lblAirport = new Label();
            lblCity = new Label();
            lblCountry = new Label();
            tabRezervasyon = new TabPage();
            panelSittingRegulation = new Panel();
            dataGridViewRezervasyon = new DataGridView();
            btnDeleteRezervasyon = new Button();
            btnUpdateRezervasyon = new Button();
            btnSaveRezervasyon = new Button();
            comboUcak = new ComboBox();
            lblUcak = new Label();
            lblLocation = new Label();
            comboLocation = new ComboBox();
            datePicker = new DateTimePicker();
            lblDate = new Label();
            txtSurname = new TextBox();
            txtName = new TextBox();
            lblSurname = new Label();
            lblGender = new Label();
            comboGender = new ComboBox();
            lblName = new Label();
            lblTCIdentityNumber = new Label();
            txtTCIdentityNumber = new MaskedTextBox();
            tabControl1.SuspendLayout();
            tabUcak.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewUcak).BeginInit();
            tabLocation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewLocation).BeginInit();
            tabRezervasyon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewRezervasyon).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabUcak);
            tabControl1.Controls.Add(tabLocation);
            tabControl1.Controls.Add(tabRezervasyon);
            tabControl1.Location = new Point(12, 12);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(983, 637);
            tabControl1.TabIndex = 0;
            tabControl1.Click += tabControl1_Click;
            // 
            // tabUcak
            // 
            tabUcak.BackColor = SystemColors.ActiveCaptionText;
            tabUcak.Controls.Add(btnDeleteUcak);
            tabUcak.Controls.Add(btnUpdateUcak);
            tabUcak.Controls.Add(btnSaveUcak);
            tabUcak.Controls.Add(dataGridViewUcak);
            tabUcak.Controls.Add(txtUcakSeatCapacity);
            tabUcak.Controls.Add(txtUcakSerialNo);
            tabUcak.Controls.Add(txtUcakBrand);
            tabUcak.Controls.Add(txtUcakModel);
            tabUcak.Controls.Add(lblUcakCapacity);
            tabUcak.Controls.Add(lblUcakSerialNo);
            tabUcak.Controls.Add(lblUcakBrand);
            tabUcak.Controls.Add(lblUcakModel);
            tabUcak.Location = new Point(4, 24);
            tabUcak.Name = "tabUcak";
            tabUcak.Padding = new Padding(3);
            tabUcak.Size = new Size(975, 609);
            tabUcak.TabIndex = 0;
            tabUcak.Text = "Ucak";
            // 
            // btnDeleteUcak
            // 
            btnDeleteUcak.FlatStyle = FlatStyle.Flat;
            btnDeleteUcak.Location = new Point(871, 6);
            btnDeleteUcak.Name = "btnDeleteUcak";
            btnDeleteUcak.Size = new Size(100, 52);
            btnDeleteUcak.TabIndex = 10;
            btnDeleteUcak.Text = "Delete";
            btnDeleteUcak.UseVisualStyleBackColor = true;
            btnDeleteUcak.Click += btnUcak_Click;
            // 
            // btnUpdateUcak
            // 
            btnUpdateUcak.FlatStyle = FlatStyle.Flat;
            btnUpdateUcak.Location = new Point(765, 6);
            btnUpdateUcak.Name = "btnUpdateUcak";
            btnUpdateUcak.Size = new Size(100, 52);
            btnUpdateUcak.TabIndex = 9;
            btnUpdateUcak.Text = "Update";
            btnUpdateUcak.UseVisualStyleBackColor = true;
            btnUpdateUcak.Click += btnUcak_Click;
            // 
            // btnSaveUcak
            // 
            btnSaveUcak.FlatStyle = FlatStyle.Flat;
            btnSaveUcak.Location = new Point(659, 6);
            btnSaveUcak.Name = "btnSaveUcak";
            btnSaveUcak.Size = new Size(100, 52);
            btnSaveUcak.TabIndex = 8;
            btnSaveUcak.Text = "Save";
            btnSaveUcak.UseVisualStyleBackColor = true;
            btnSaveUcak.Click += btnUcak_Click;
            // 
            // dataGridViewUcak
            // 
            dataGridViewUcak.AllowUserToAddRows = false;
            dataGridViewUcak.AllowUserToDeleteRows = false;
            dataGridViewUcak.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewUcak.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewUcak.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewUcak.Location = new Point(5, 64);
            dataGridViewUcak.Name = "dataGridViewUcak";
            dataGridViewUcak.ReadOnly = true;
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewUcak.RowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewUcak.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewUcak.Size = new Size(964, 539);
            dataGridViewUcak.TabIndex = 11;
            dataGridViewUcak.CellClick += dataGridViewUcak_CellClick;
            // 
            // txtUcakSeatCapacity
            // 
            txtUcakSeatCapacity.Location = new Point(443, 35);
            txtUcakSeatCapacity.Mask = "0000";
            txtUcakSeatCapacity.Name = "txtUcakSeatCapacity";
            txtUcakSeatCapacity.Size = new Size(210, 23);
            txtUcakSeatCapacity.TabIndex = 7;
            txtUcakSeatCapacity.TextAlign = HorizontalAlignment.Center;
            // 
            // txtUcakSerialNo
            // 
            txtUcakSerialNo.Location = new Point(443, 6);
            txtUcakSerialNo.Name = "txtUcakSerialNo";
            txtUcakSerialNo.Size = new Size(210, 23);
            txtUcakSerialNo.TabIndex = 5;
            // 
            // txtUcakBrand
            // 
            txtUcakBrand.Location = new Point(98, 35);
            txtUcakBrand.Name = "txtUcakBrand";
            txtUcakBrand.Size = new Size(210, 23);
            txtUcakBrand.TabIndex = 6;
            // 
            // txtUcakModel
            // 
            txtUcakModel.Location = new Point(98, 6);
            txtUcakModel.Name = "txtUcakModel";
            txtUcakModel.Size = new Size(210, 23);
            txtUcakModel.TabIndex = 4;
            // 
            // lblUcakCapacity
            // 
            lblUcakCapacity.AutoSize = true;
            lblUcakCapacity.Location = new Point(314, 38);
            lblUcakCapacity.Name = "lblUcakCapacity";
            lblUcakCapacity.Size = new Size(123, 15);
            lblUcakCapacity.TabIndex = 3;
            lblUcakCapacity.Text = "Ucak Seat Capacity:";
            // 
            // lblUcakSerialNo
            // 
            lblUcakSerialNo.AutoSize = true;
            lblUcakSerialNo.Location = new Point(338, 9);
            lblUcakSerialNo.Name = "lblUcakSerialNo";
            lblUcakSerialNo.Size = new Size(99, 15);
            lblUcakSerialNo.TabIndex = 1;
            lblUcakSerialNo.Text = "Ucak Serial No:";
            // 
            // lblUcakBrand
            // 
            lblUcakBrand.AutoSize = true;
            lblUcakBrand.Location = new Point(9, 38);
            lblUcakBrand.Name = "lblUcakBrand";
            lblUcakBrand.Size = new Size(83, 15);
            lblUcakBrand.TabIndex = 2;
            lblUcakBrand.Text = "Ucak Brand:";
            // 
            // lblUcakModel
            // 
            lblUcakModel.AutoSize = true;
            lblUcakModel.Location = new Point(6, 9);
            lblUcakModel.Name = "lblUcakModel";
            lblUcakModel.Size = new Size(86, 15);
            lblUcakModel.TabIndex = 0;
            lblUcakModel.Text = "Ucak Model:";
            // 
            // tabLocation
            // 
            tabLocation.BackColor = SystemColors.ActiveCaptionText;
            tabLocation.Controls.Add(btnDeleteLocation);
            tabLocation.Controls.Add(btnUpdateLocation);
            tabLocation.Controls.Add(comboActivePassive);
            tabLocation.Controls.Add(btnSaveLocation);
            tabLocation.Controls.Add(comboAirport);
            tabLocation.Controls.Add(comboCity);
            tabLocation.Controls.Add(comboCountry);
            tabLocation.Controls.Add(dataGridViewLocation);
            tabLocation.Controls.Add(lblActivePassive);
            tabLocation.Controls.Add(lblAirport);
            tabLocation.Controls.Add(lblCity);
            tabLocation.Controls.Add(lblCountry);
            tabLocation.Location = new Point(4, 24);
            tabLocation.Name = "tabLocation";
            tabLocation.Padding = new Padding(3);
            tabLocation.Size = new Size(975, 609);
            tabLocation.TabIndex = 1;
            tabLocation.Text = "Location";
            // 
            // btnDeleteLocation
            // 
            btnDeleteLocation.FlatStyle = FlatStyle.Flat;
            btnDeleteLocation.Location = new Point(869, 6);
            btnDeleteLocation.Name = "btnDeleteLocation";
            btnDeleteLocation.Size = new Size(100, 52);
            btnDeleteLocation.TabIndex = 10;
            btnDeleteLocation.Text = "Delete";
            btnDeleteLocation.UseVisualStyleBackColor = true;
            btnDeleteLocation.Click += btnLocation_Click;
            // 
            // btnUpdateLocation
            // 
            btnUpdateLocation.FlatStyle = FlatStyle.Flat;
            btnUpdateLocation.Location = new Point(763, 6);
            btnUpdateLocation.Name = "btnUpdateLocation";
            btnUpdateLocation.Size = new Size(100, 52);
            btnUpdateLocation.TabIndex = 9;
            btnUpdateLocation.Text = "Update";
            btnUpdateLocation.UseVisualStyleBackColor = true;
            btnUpdateLocation.Click += btnLocation_Click;
            // 
            // comboActivePassive
            // 
            comboActivePassive.DropDownStyle = ComboBoxStyle.DropDownList;
            comboActivePassive.FormattingEnabled = true;
            comboActivePassive.IntegralHeight = false;
            comboActivePassive.Items.AddRange(new object[] { "", "Active", "Passive" });
            comboActivePassive.Location = new Point(403, 35);
            comboActivePassive.MaxDropDownItems = 4;
            comboActivePassive.Name = "comboActivePassive";
            comboActivePassive.Size = new Size(240, 23);
            comboActivePassive.TabIndex = 7;
            // 
            // btnSaveLocation
            // 
            btnSaveLocation.FlatStyle = FlatStyle.Flat;
            btnSaveLocation.Location = new Point(657, 6);
            btnSaveLocation.Name = "btnSaveLocation";
            btnSaveLocation.Size = new Size(100, 52);
            btnSaveLocation.TabIndex = 8;
            btnSaveLocation.Text = "Save";
            btnSaveLocation.UseVisualStyleBackColor = true;
            btnSaveLocation.Click += btnLocation_Click;
            // 
            // comboAirport
            // 
            comboAirport.DropDownStyle = ComboBoxStyle.DropDownList;
            comboAirport.FormattingEnabled = true;
            comboAirport.IntegralHeight = false;
            comboAirport.Location = new Point(65, 35);
            comboAirport.MaxDropDownItems = 4;
            comboAirport.Name = "comboAirport";
            comboAirport.Size = new Size(240, 23);
            comboAirport.TabIndex = 6;
            // 
            // comboCity
            // 
            comboCity.DropDownStyle = ComboBoxStyle.DropDownList;
            comboCity.FormattingEnabled = true;
            comboCity.IntegralHeight = false;
            comboCity.Location = new Point(403, 6);
            comboCity.MaxDropDownItems = 4;
            comboCity.Name = "comboCity";
            comboCity.Size = new Size(240, 23);
            comboCity.TabIndex = 5;
            comboCity.SelectedIndexChanged += comboCity_SelectedIndexChanged;
            // 
            // comboCountry
            // 
            comboCountry.DropDownStyle = ComboBoxStyle.DropDownList;
            comboCountry.FormattingEnabled = true;
            comboCountry.IntegralHeight = false;
            comboCountry.Location = new Point(65, 6);
            comboCountry.MaxDropDownItems = 4;
            comboCountry.Name = "comboCountry";
            comboCountry.Size = new Size(240, 23);
            comboCountry.TabIndex = 4;
            comboCountry.SelectedIndexChanged += comboCountry_SelectedIndexChanged;
            // 
            // dataGridViewLocation
            // 
            dataGridViewLocation.AllowUserToAddRows = false;
            dataGridViewLocation.AllowUserToDeleteRows = false;
            dataGridViewLocation.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewLocation.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewLocation.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewLocation.Location = new Point(6, 64);
            dataGridViewLocation.Name = "dataGridViewLocation";
            dataGridViewLocation.ReadOnly = true;
            dataGridViewLocation.RowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewLocation.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewLocation.Size = new Size(963, 539);
            dataGridViewLocation.TabIndex = 11;
            dataGridViewLocation.CellClick += dataGridViewLocation_CellClick;
            // 
            // lblActivePassive
            // 
            lblActivePassive.AutoSize = true;
            lblActivePassive.Location = new Point(311, 40);
            lblActivePassive.Name = "lblActivePassive";
            lblActivePassive.Size = new Size(86, 15);
            lblActivePassive.TabIndex = 3;
            lblActivePassive.Text = "Active-Passive:";
            // 
            // lblAirport
            // 
            lblAirport.AutoSize = true;
            lblAirport.Location = new Point(12, 38);
            lblAirport.Name = "lblAirport";
            lblAirport.Size = new Size(47, 15);
            lblAirport.TabIndex = 2;
            lblAirport.Text = "Airport:";
            // 
            // lblCity
            // 
            lblCity.AutoSize = true;
            lblCity.Location = new Point(366, 9);
            lblCity.Name = "lblCity";
            lblCity.Size = new Size(31, 15);
            lblCity.TabIndex = 1;
            lblCity.Text = "City:";
            // 
            // lblCountry
            // 
            lblCountry.AutoSize = true;
            lblCountry.Location = new Point(6, 11);
            lblCountry.Name = "lblCountry";
            lblCountry.Size = new Size(53, 15);
            lblCountry.TabIndex = 0;
            lblCountry.Text = "Country:";
            // 
            // tabRezervasyon
            // 
            tabRezervasyon.BackColor = SystemColors.ActiveCaptionText;
            tabRezervasyon.Controls.Add(panelSittingRegulation);
            tabRezervasyon.Controls.Add(dataGridViewRezervasyon);
            tabRezervasyon.Controls.Add(btnDeleteRezervasyon);
            tabRezervasyon.Controls.Add(btnUpdateRezervasyon);
            tabRezervasyon.Controls.Add(btnSaveRezervasyon);
            tabRezervasyon.Controls.Add(comboUcak);
            tabRezervasyon.Controls.Add(lblUcak);
            tabRezervasyon.Controls.Add(lblLocation);
            tabRezervasyon.Controls.Add(comboLocation);
            tabRezervasyon.Controls.Add(datePicker);
            tabRezervasyon.Controls.Add(lblDate);
            tabRezervasyon.Controls.Add(txtSurname);
            tabRezervasyon.Controls.Add(txtName);
            tabRezervasyon.Controls.Add(lblSurname);
            tabRezervasyon.Controls.Add(lblGender);
            tabRezervasyon.Controls.Add(comboGender);
            tabRezervasyon.Controls.Add(lblName);
            tabRezervasyon.Controls.Add(lblTCIdentityNumber);
            tabRezervasyon.Controls.Add(txtTCIdentityNumber);
            tabRezervasyon.Location = new Point(4, 24);
            tabRezervasyon.Name = "tabRezervasyon";
            tabRezervasyon.Size = new Size(975, 609);
            tabRezervasyon.TabIndex = 2;
            tabRezervasyon.Text = "Rezervasyon";
            // 
            // panelSittingRegulation
            // 
            panelSittingRegulation.Location = new Point(6, 95);
            panelSittingRegulation.Name = "panelSittingRegulation";
            panelSittingRegulation.Size = new Size(415, 499);
            panelSittingRegulation.TabIndex = 18;
            // 
            // dataGridViewRezervasyon
            // 
            dataGridViewRezervasyon.AllowUserToAddRows = false;
            dataGridViewRezervasyon.AllowUserToDeleteRows = false;
            dataGridViewRezervasyon.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewRezervasyon.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewRezervasyon.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewRezervasyon.Location = new Point(427, 95);
            dataGridViewRezervasyon.Name = "dataGridViewRezervasyon";
            dataGridViewRezervasyon.ReadOnly = true;
            dataGridViewRezervasyon.RowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewRezervasyon.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewRezervasyon.Size = new Size(538, 499);
            dataGridViewRezervasyon.TabIndex = 17;
            dataGridViewRezervasyon.CellClick += dataGridViewRezervasyon_CellClick;
            // 
            // btnDeleteRezervasyon
            // 
            btnDeleteRezervasyon.FlatStyle = FlatStyle.Flat;
            btnDeleteRezervasyon.Location = new Point(865, 37);
            btnDeleteRezervasyon.Name = "btnDeleteRezervasyon";
            btnDeleteRezervasyon.Size = new Size(100, 52);
            btnDeleteRezervasyon.TabIndex = 16;
            btnDeleteRezervasyon.Text = "Delete";
            btnDeleteRezervasyon.UseVisualStyleBackColor = true;
            btnDeleteRezervasyon.Click += btnRezervasyon_Click;
            // 
            // btnUpdateRezervasyon
            // 
            btnUpdateRezervasyon.FlatStyle = FlatStyle.Flat;
            btnUpdateRezervasyon.Location = new Point(759, 37);
            btnUpdateRezervasyon.Name = "btnUpdateRezervasyon";
            btnUpdateRezervasyon.Size = new Size(100, 52);
            btnUpdateRezervasyon.TabIndex = 15;
            btnUpdateRezervasyon.Text = "Update";
            btnUpdateRezervasyon.UseVisualStyleBackColor = true;
            btnUpdateRezervasyon.Click += btnRezervasyon_Click;
            // 
            // btnSaveRezervasyon
            // 
            btnSaveRezervasyon.FlatStyle = FlatStyle.Flat;
            btnSaveRezervasyon.Location = new Point(653, 37);
            btnSaveRezervasyon.Name = "btnSaveRezervasyon";
            btnSaveRezervasyon.Size = new Size(100, 52);
            btnSaveRezervasyon.TabIndex = 14;
            btnSaveRezervasyon.Text = "Save";
            btnSaveRezervasyon.UseVisualStyleBackColor = true;
            btnSaveRezervasyon.Click += btnRezervasyon_Click;
            // 
            // comboUcak
            // 
            comboUcak.DropDownStyle = ComboBoxStyle.DropDownList;
            comboUcak.FormattingEnabled = true;
            comboUcak.IntegralHeight = false;
            comboUcak.Location = new Point(61, 8);
            comboUcak.MaxDropDownItems = 4;
            comboUcak.Name = "comboUcak";
            comboUcak.Size = new Size(220, 23);
            comboUcak.TabIndex = 7;
            // 
            // lblUcak
            // 
            lblUcak.AutoSize = true;
            lblUcak.Location = new Point(6, 11);
            lblUcak.Name = "lblUcak";
            lblUcak.Size = new Size(49, 15);
            lblUcak.TabIndex = 0;
            lblUcak.Text = "Ucak:";
            // 
            // lblLocation
            // 
            lblLocation.AutoSize = true;
            lblLocation.Location = new Point(287, 11);
            lblLocation.Name = "lblLocation";
            lblLocation.Size = new Size(56, 15);
            lblLocation.TabIndex = 1;
            lblLocation.Text = "Location:";
            // 
            // comboLocation
            // 
            comboLocation.DropDownStyle = ComboBoxStyle.DropDownList;
            comboLocation.FormattingEnabled = true;
            comboLocation.IntegralHeight = false;
            comboLocation.Location = new Point(349, 8);
            comboLocation.MaxDropDownItems = 4;
            comboLocation.Name = "comboLocation";
            comboLocation.Size = new Size(350, 23);
            comboLocation.TabIndex = 8;
            // 
            // datePicker
            // 
            datePicker.Location = new Point(745, 8);
            datePicker.Name = "datePicker";
            datePicker.Size = new Size(220, 23);
            datePicker.TabIndex = 9;
            datePicker.Value = DateTime.Now;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Location = new Point(705, 11);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(34, 15);
            lblDate.TabIndex = 2;
            lblDate.Text = "Date:";
            // 
            // txtSurname
            // 
            txtSurname.Location = new Point(427, 37);
            txtSurname.Name = "txtSurname";
            txtSurname.Size = new Size(220, 23);
            txtSurname.TabIndex = 11;
            // 
            // txtName
            // 
            txtName.Location = new Point(138, 37);
            txtName.Name = "txtName";
            txtName.Size = new Size(220, 23);
            txtName.TabIndex = 10;
            // 
            // lblSurname
            // 
            lblSurname.AutoSize = true;
            lblSurname.Location = new Point(364, 40);
            lblSurname.Name = "lblSurname";
            lblSurname.Size = new Size(57, 15);
            lblSurname.TabIndex = 4;
            lblSurname.Text = "Surname:";
            // 
            // lblGender
            // 
            lblGender.AutoSize = true;
            lblGender.Location = new Point(373, 69);
            lblGender.Name = "lblGender";
            lblGender.Size = new Size(48, 15);
            lblGender.TabIndex = 6;
            lblGender.Text = "Gender:";
            // 
            // comboGender
            // 
            comboGender.DropDownStyle = ComboBoxStyle.DropDownList;
            comboGender.FormattingEnabled = true;
            comboGender.IntegralHeight = false;
            comboGender.Items.AddRange(new object[] { "", "Female", "Male" });
            comboGender.Location = new Point(427, 66);
            comboGender.MaxDropDownItems = 4;
            comboGender.Name = "comboGender";
            comboGender.Size = new Size(220, 23);
            comboGender.TabIndex = 13;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(90, 40);
            lblName.Name = "lblName";
            lblName.Size = new Size(42, 15);
            lblName.TabIndex = 3;
            lblName.Text = "Name:";
            // 
            // lblTCIdentityNumber
            // 
            lblTCIdentityNumber.AutoSize = true;
            lblTCIdentityNumber.Location = new Point(12, 69);
            lblTCIdentityNumber.Name = "lblTCIdentityNumber";
            lblTCIdentityNumber.Size = new Size(120, 15);
            lblTCIdentityNumber.TabIndex = 5;
            lblTCIdentityNumber.Text = "T.C. Identity Number:";
            // 
            // txtTCIdentityNumber
            // 
            txtTCIdentityNumber.Location = new Point(138, 66);
            txtTCIdentityNumber.Mask = "00000000000";
            txtTCIdentityNumber.Name = "txtTCIdentityNumber";
            txtTCIdentityNumber.Size = new Size(220, 23);
            txtTCIdentityNumber.TabIndex = 12;
            txtTCIdentityNumber.TextAlign = HorizontalAlignment.Center;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1007, 661);
            Controls.Add(tabControl1);
            ForeColor = SystemColors.ButtonHighlight;
            KeyPreview = true;
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Flight Ticket Booking App";
            KeyDown += MainForm_KeyDown;
            tabControl1.ResumeLayout(false);
            tabUcak.ResumeLayout(false);
            tabUcak.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewUcak).EndInit();
            tabLocation.ResumeLayout(false);
            tabLocation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewLocation).EndInit();
            tabRezervasyon.ResumeLayout(false);
            tabRezervasyon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewRezervasyon).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabUcak;
        private TabPage tabLocation;
        private TabPage tabRezervasyon;
        private Label lblUcakModel;
        private Label lblUcakBrand;
        private Label lblUcakSerialNo;
        private Label lblUcakCapacity;
        private Label lblCountry;
        private Label lblCity;
        private Label lblAirport;
        private Label lblActivePassive;
        private Label lblUcak;
        private Label lblLocation;
        private Label lblDate;
        private Label lblName;
        private Label lblSurname;
        private Label lblTCIdentityNumber;
        private Label lblGender;
        private Button btnSaveUcak;
        private Button btnUpdateUcak;
        private Button btnDeleteUcak;
        private Button btnSaveLocation;
        private Button btnUpdateLocation;
        private Button btnDeleteLocation;
        private Button btnSaveRezervasyon;
        private Button btnUpdateRezervasyon;
        private Button btnDeleteRezervasyon;
        public static Panel panelSittingRegulation;
        public static TextBox txtUcakModel;
        public static TextBox txtUcakBrand;
        public static TextBox txtUcakSerialNo;
        public static TextBox txtName;
        public static TextBox txtSurname;
        public static MaskedTextBox txtUcakSeatCapacity;
        public static MaskedTextBox txtTCIdentityNumber;
        public static DateTimePicker datePicker;
        public static ComboBox comboCountry;
        public static ComboBox comboCity;
        public static ComboBox comboAirport;
        public static ComboBox comboActivePassive;
        public static ComboBox comboUcak;
        public static ComboBox comboLocation;
        public static ComboBox comboGender;
        public static DataGridView dataGridViewUcak;
        public static DataGridView dataGridViewLocation;
        public static DataGridView dataGridViewRezervasyon;
    }
}

/*
        public static Panel panelSittingRegulation;
        public static TextBox txtUcakModel;
        public static TextBox txtUcakBrand;
        public static TextBox txtUcakSerialNo;
        public static TextBox txtName;
        public static TextBox txtSurname;
        public static MaskedTextBox txtUcakSeatCapacity;
        public static MaskedTextBox txtTCIdentityNumber;
        public static DateTimePicker datePicker;
        public static ComboBox comboCountry;
        public static ComboBox comboCity;
        public static ComboBox comboAirport;
        public static ComboBox comboActivePassive;
        public static ComboBox comboUcak;
        public static ComboBox comboLocation;
        public static ComboBox comboGender;
        public static DataGridView dataGridViewUcak;
        public static DataGridView dataGridViewLocation;
        public static DataGridView dataGridViewRezervasyon;
*/