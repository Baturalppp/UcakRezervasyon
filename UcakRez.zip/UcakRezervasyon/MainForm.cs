# pragma warning disable

using UcakRezervasyon.Control_Data;
using UcakRezervasyon.Models;

namespace UcakRezervasyon
{
    public partial class MainForm : Form
    {
        public static int seatNo = 0;

        public MainForm()
        {
            InitializeComponent();

            LocationGenerate.fillCountries();

            Ucak.loadData();
            Control_Data.Location.loadData();
            Rezervasyon.loadData();

            Rezervasyon.fillSeat();
        }

        #region button

        private void btnUcak_Click(object sender, EventArgs e)
        {
            if (txtUcakModel.Text != string.Empty && txtUcakBrand.Text != string.Empty && txtUcakSerialNo.Text != string.Empty && txtUcakSeatCapacity.Text != string.Empty && seatNo != 0)
            {
                ModelUcak Ucak = new ModelUcak
                {
                    UcakModel = txtUcakModel.Text,
                    UcakBrand = txtUcakBrand.Text,
                    UcakSerialNo = txtUcakSerialNo.Text,
                    UcakSeatCapacity = int.Parse(txtUcakSeatCapacity.Text)
                };

                if (sender == btnSaveUcak)
                    Ucak.save(Ucak);
                if (sender == btnUpdateUcak)
                    Ucak.update(Ucak);
                if (sender == btnDeleteUcak)
                    Ucak.delete();

                Ucak.clearData();
            }
            else
            {
                MessageBox.Show("Do Not Leave Empty Space.", "Free Space Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLocation_Click(object sender, EventArgs e)
        {
            if (comboCountry.SelectedValue != null && comboCity.SelectedValue != null && comboAirport.SelectedValue != null && comboActivePassive.SelectedIndex != 0)
            {
                bool status = false;
                if (comboActivePassive.SelectedItem.ToString() == "Active")
                    status = true;

                ModelLocation Location = new ModelLocation
                {
                    Country = comboCountry.SelectedItem.ToString(),
                    City = comboCity.SelectedItem.ToString(),
                    Airport = comboAirport.SelectedItem.ToString(),
                    ActivePassive = status
                };

                if (sender == btnSaveLocation)
                    Control_Data.Location.save(Location);
                if (sender == btnUpdateLocation)
                    Control_Data.Location.update(Location);
                if (sender == btnDeleteLocation)
                    Control_Data.Location.delete();

                Control_Data.Location.clearData();
            }
            else
            {
                MessageBox.Show("Do Not Leave Empty Space.", "Free Space Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRezervasyon_Click(object sender, EventArgs e)
        {
            if (comboUcak.SelectedValue != null && comboLocation.SelectedValue != null && datePicker.Value != null && txtName.Text != string.Empty && txtSurname.Text != string.Empty && txtTCIdentityNumber.Text != string.Empty && comboGender.SelectedItem != "" && seatNo > 0)
            {
                if (datePicker.Value.Date >= DateTime.Now.Date)
                {
                    if (txtTCIdentityNumber.Text.Length == 11)
                    {
                        ModelRezervasyon Rezervasyon = new ModelRezervasyon
                        {
                            UcakId = (int)comboUcak.SelectedValue,
                            LocationId = (int)comboLocation.SelectedValue,
                            Date = datePicker.Value,
                            CustomerName = txtName.Text,
                            CustomerSurname = txtSurname.Text,
                            CustomerIDNo = txtTCIdentityNumber.Text,
                            CustomerGender = comboGender.SelectedItem.ToString(),
                            SeatNo = seatNo
                        };

                        if (sender == btnSaveRezervasyon)
                            Rezervasyon.save(Rezervasyon);
                        if (sender == btnUpdateRezervasyon)
                            Rezervasyon.update(Rezervasyon);
                        if (sender == btnDeleteRezervasyon)
                            Rezervasyon.delete();

                        Rezervasyon.clearData();

                        seatNo = 0;
                    }
                    else
                    {
                        MessageBox.Show("T.C. Identity Number Consists of 11 Digits.", "Data Format Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("You Cannot Select A Date Before Today.", "Data Format Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Do Not Leave Empty Space.", "Free Space Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion button

        #region dataGridView

        private void dataGridViewUcak_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DB.ControlDB())
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridViewUcak.Rows[e.RowIndex];
                    txtUcakModel.Text = row.Cells["UcakModel"].Value.ToString();
                    txtUcakBrand.Text = row.Cells["UcakBrand"].Value.ToString();
                    txtUcakSerialNo.Text = row.Cells["UcakSerialNo"].Value.ToString();
                    txtUcakSeatCapacity.Text = row.Cells["UcakSeatCapacity"].Value.ToString();
                }
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridViewLocation_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DB.ControlDB())
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridViewLocation.Rows[e.RowIndex];
                    comboCountry.SelectedItem = row.Cells["Country"].Value.ToString();
                    comboCity.SelectedItem = row.Cells["City"].Value.ToString();
                    comboAirport.SelectedItem = row.Cells["Airport"].Value.ToString();
                    if (Convert.ToBoolean(row.Cells["ActivePassive"].Value))
                        comboActivePassive.SelectedItem = "Active";
                    else
                        comboActivePassive.SelectedItem = "Passive";
                }
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridViewRezervasyon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DB.ControlDB())
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridViewRezervasyon.Rows[e.RowIndex];
                    comboUcak.SelectedItem = row.Cells["UcakId"].Value.ToString();
                    comboLocation.SelectedItem = row.Cells["LocationId"].Value.ToString();
                    datePicker.Value = (DateTime)row.Cells["Date"].Value;
                    txtName.Text = row.Cells["CustomerName"].Value.ToString();
                    txtSurname.Text = row.Cells["CustomerSurname"].Value.ToString();
                    txtTCIdentityNumber.Text = row.Cells["CustomerIDNo"].Value.ToString();
                    comboGender.SelectedItem = row.Cells["CustomerGender"].Value.ToString();
                    seatNo = int.Parse(row.Cells["SeatNo"].Value.ToString());
                }
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion dataGridView

        private void tabControl1_Click(object sender, EventArgs e)
        {
            Rezervasyon.fillUcak();
            Rezervasyon.fillLocation();
        }

        #region comboBox

        private void comboCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            LocationGenerate.fillCities(comboCountry.SelectedItem.ToString());
            comboCity.SelectedIndex = -1;
            comboAirport.DataSource = null;
        }

        private void comboCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboCity.SelectedIndex >= 0)
            {
                LocationGenerate.fillAirports(comboCountry.SelectedItem.ToString(), comboCity.SelectedItem.ToString());
                comboAirport.SelectedIndex = -1;
            }
        }

        #endregion comboBox

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                Application.Exit();
        }
    }
}
