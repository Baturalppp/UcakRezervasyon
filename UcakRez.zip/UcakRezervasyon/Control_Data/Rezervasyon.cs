﻿# pragma warning disable

using UcakRezervasyon.Models;

namespace UcakRezervasyon.Control_Data
{
    public static class Rezervasyon
    {
        public static void save(ModelRezervasyon Rezervasyon)
        {
            if (DB.ControlDB())
            {
                DB.dbContext.Rezervasyons.Add(Rezervasyon);
                DB.dbContext.SaveChanges();
                loadData();
                MainForm.panelSittingRegulation.Controls.Clear();
                fillSeat();
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void update(ModelRezervasyon Rezervasyon)
        {
            if (DB.ControlDB())
            {
                if (MainForm.dataGridViewRezervasyon.SelectedRows.Count > 0)
                {
                    int id = int.Parse(MainForm.dataGridViewRezervasyon.SelectedRows[0].Cells[0].Value.ToString());
                    ModelRezervasyon selectedRezervasyon = DB.dbContext.Rezervasyons.Find(id);
                    if (selectedRezervasyon != null)
                    {
                        selectedRezervasyon.UcakId = Rezervasyon.UcakId;
                        selectedRezervasyon.LocationId = Rezervasyon.LocationId;
                        selectedRezervasyon.Date = Rezervasyon.Date;
                        selectedRezervasyon.CustomerName = Rezervasyon.CustomerName;
                        selectedRezervasyon.CustomerSurname = Rezervasyon.CustomerSurname;
                        selectedRezervasyon.CustomerIDNo = Rezervasyon.CustomerIDNo;
                        selectedRezervasyon.CustomerGender = Rezervasyon.CustomerGender;
                        selectedRezervasyon.SeatNo = Rezervasyon.SeatNo;
                        DB.dbContext.SaveChanges();
                        loadData();
                        MainForm.panelSittingRegulation.Controls.Clear();
                        fillSeat();
                    }
                }
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void delete()
        {
            if (DB.ControlDB())
            {
                if (MainForm.dataGridViewRezervasyon.SelectedRows.Count > 0)
                {
                    int id = int.Parse(MainForm.dataGridViewRezervasyon.SelectedRows[0].Cells[0].Value.ToString());
                    ModelRezervasyon selectedRezervasyon = DB.dbContext.Rezervasyons.Find(id);
                    if (selectedRezervasyon != null)
                    {
                        DB.dbContext.Rezervasyons.Remove(selectedRezervasyon);
                        DB.dbContext.SaveChanges();
                        loadData();
                        MainForm.panelSittingRegulation.Controls.Clear();
                        fillSeat();
                    }
                }
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void loadData()
        {
            if (DB.ControlDB())
            {
                MainForm.dataGridViewRezervasyon.DataSource = DB.dbContext.Rezervasyons.ToList();

                MainForm.dataGridViewRezervasyon.Columns[0].Visible = false;
                MainForm.dataGridViewRezervasyon.Columns[1].Visible = false;
                MainForm.dataGridViewRezervasyon.Columns[2].Visible = false;
                MainForm.dataGridViewRezervasyon.Columns[3].Visible = false;
                MainForm.dataGridViewRezervasyon.Columns[4].HeaderText = "Name";
                MainForm.dataGridViewRezervasyon.Columns[5].HeaderText = "Surname";
                MainForm.dataGridViewRezervasyon.Columns[6].HeaderText = "ID No";
                MainForm.dataGridViewRezervasyon.Columns[7].HeaderText = "Gender";
                MainForm.dataGridViewRezervasyon.Columns[8].HeaderText = "Seat No";
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void clearData()
        {
            MainForm.txtTCIdentityNumber.Text = null;
            MainForm.txtName.Text = null;
            MainForm.txtSurname.Text = null;
            MainForm.comboGender.SelectedItem = "";
            MainForm.datePicker.Value = DateTime.Now;
        }

        public static void fillUcak()
        {
            if (DB.ControlDB())
            {
                var Ucaks = DB.dbContext.Ucaks.ToList();
                MainForm.comboUcak.DataSource = Ucaks;
                MainForm.comboUcak.DisplayMember = "UcakModel";
                MainForm.comboUcak.ValueMember = "IdUcak";
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void fillLocation()
        {
            if (DB.ControlDB())
            {
                var Locations = DB.dbContext.Locations.Where(obj => obj.ActivePassive == true).ToList();
                MainForm.comboLocation.DataSource = Locations;
                MainForm.comboLocation.DisplayMember = "Airport";
                MainForm.comboLocation.ValueMember = "IdLocation";
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void fillSeat()
        {
            List<int> seats = DB.dbContext.Rezervasyons.Select(obj => obj.SeatNo).ToList();

            int x = 20;
            int y = 20;
            int buttonWidth = 75;
            int buttonHeight = 23;
            int tabIndex = 1;

            for (int row = 0; row < 20; row++)
            {
                for (int col = 0; col < 4; col++)
                {
                    Button button = new Button();
                    button.Text = $"{tabIndex}";
                    button.Location = new System.Drawing.Point(x, y);
                    button.Size = new System.Drawing.Size(buttonWidth, buttonHeight);
                    button.TabIndex = tabIndex;
                    if (seats.Contains(tabIndex))
                        button.BackColor = System.Drawing.Color.Red;
                    else
                        button.BackColor = System.Drawing.Color.Green;
                    button.FlatStyle = FlatStyle.Flat;
                    button.Click += button_Click;
                    MainForm.panelSittingRegulation.Controls.Add(button);

                    x += buttonWidth + 1;
                    tabIndex++;

                    if (col == 1)
                    {
                        x += buttonWidth + 1;
                    }
                }

                x = 20;
                y += buttonHeight + 1;
            }
        }

        private static void button_Click(object sender, EventArgs e)
        {
            if (sender is Button button)
            {
                int seat = int.Parse(button.Text);
                MainForm.seatNo = seat;
            }
        }
    }
}
