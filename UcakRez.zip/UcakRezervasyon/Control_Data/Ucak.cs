﻿# pragma warning disable

using UcakRezervasyon.Models;

namespace UcakRezervasyon.Control_Data
{
    public static class Ucak
    {
        public static void save(ModelUcak Ucak)
        {
            if (DB.ControlDB())
            {
                DB.dbContext.Ucaks.Add(Ucak);
                DB.dbContext.SaveChanges();
                loadData();
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void update(ModelUcak Ucak)
        {
            if (DB.ControlDB())
            {
                if (MainForm.dataGridViewUcak.SelectedRows.Count > 0)
                {
                    int id = int.Parse(MainForm.dataGridViewUcak.SelectedRows[0].Cells[0].Value.ToString());
                    ModelUcak selectedUcak = DB.dbContext.Ucaks.Find(id);
                    if (selectedUcak != null)
                    {
                        selectedUcak.UcakModel = Ucak.UcakModel;
                        selectedUcak.UcakBrand = Ucak.UcakBrand;
                        selectedUcak.UcakSerialNo = Ucak.UcakSerialNo;
                        selectedUcak.UcakSeatCapacity = Ucak.UcakSeatCapacity;
                        DB.dbContext.SaveChanges();
                        loadData();
                    }
                }
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void delete()
        {
            if (DB.ControlDB())
            {
                if (MainForm.dataGridViewUcak.SelectedRows.Count > 0)
                {
                    int id = int.Parse(MainForm.dataGridViewUcak.SelectedRows[0].Cells[0].Value.ToString());
                    ModelUcak selectedUcak = DB.dbContext.Ucaks.Find(id);
                    if (selectedUcak != null)
                    {
                        DB.dbContext.Ucaks.Remove(selectedUcak);
                        DB.dbContext.SaveChanges();
                        loadData();
                    }
                }
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void loadData()
        {
            if (DB.ControlDB())
            {
                MainForm.dataGridViewUcak.DataSource = DB.dbContext.Ucaks.ToList();

                MainForm.dataGridViewUcak.Columns[0].HeaderText = "Ucak ID";
                MainForm.dataGridViewUcak.Columns[1].HeaderText = "Ucak Model";
                MainForm.dataGridViewUcak.Columns[2].HeaderText = "Ucak Brand";
                MainForm.dataGridViewUcak.Columns[3].HeaderText = "Ucak Serial No";
                MainForm.dataGridViewUcak.Columns[4].HeaderText = "Ucak Seat Capacity";
            }
            else
            {
                MessageBox.Show("Error Establishing Connection with Database.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void clearData()
        {
            MainForm.txtUcakModel.Text = null;
            MainForm.txtUcakBrand.Text = null;
            MainForm.txtUcakSerialNo.Text = null;
            MainForm.txtUcakSeatCapacity.Text = null;
        }
    }
}
