﻿# pragma warning disable

namespace UcakRezervasyon.Control_Data
{
    public static class LocationGenerate
    {
        public struct Location (string country, string city, string airport)
        {
            public string Country = country;
            public string City = city;
            public string Airport = airport;
        }

        public static List<Location> Locations = new List<Location>
        {
            new Location("", "", ""),
            new Location("ABD", "Lansing", "Capital Region Uluslararası Havalimanı (LAN)"),
            new Location("ABD", "Laredo", "Laredo Uluslararası Havalimanı (LRD)"),
            new Location("ABD", "Las Vegas", "Las Vegas Mccarran Uluslararası Havalimanı (LAS)"),
            new Location("ABD", "Lexington", "Blue Grass Havalimanı (LEX)"),
            new Location("ABD", "Lihue", "Lihue Havalimanı (LIH)"),
            new Location("ABD", "Lincoln", "Lincoln Havalimanı (LNK)"),
            new Location("ABD", "Little Rock", "B. & H. Clinton Ulusal Havalimanı (LIT)"),
            new Location("ABD", "Long Beach", "Longbeach Havalimanı (LGB)"),
            new Location("ABD", "Los Angeles", "Los Angeles Uluslararası Havalimanı (LAX)"),
            new Location("ABD", "Louisville", "Uluslararası-Standiford Havalimanı (SDF)"),
            new Location("ABD", "Lubbock", "Preston Smith Uluslararası Havalimanı (LBB)"),
            new Location("ABD", "Madison", "Dane County Bölgesel Havalimanı (MSN)"),
            new Location("ABD", "Mammoth Lakes", "Mammoth Yosemite Havalimanı (MMH)"),
            new Location("ABD", "Manchester", "Manchester-Boston Bölgesel Havalimanı (MHT)"),
            new Location("ABD", "Martha's Vineyard", "Martha's Vineyard Havalimanı (MVY)"),
            new Location("ABD", "McAllen/Mission", "Miller Uluslararası Havalimanı (MFE)"),
            new Location("ABD", "Medford", "Rogue Valley Uluslararası Havalimanı (MFR)"),
            new Location("ABD", "Memphis", "Memphis Uluslararası Havalimanı (MEM)"),
            new Location("ABD", "Miami", "Miami Uluslararası Havalimanı (MIA)"),
            new Location("ABD", "Midland", "Midland Uluslararası Havalimanı (MAF)"),
            new Location("ABD", "Milwaukee", "General Mitchell Uluslararası Havalimanı (MKE)"),
            new Location("ABD", "Minneapolis", "Minneapolis-Saint Paul Uluslararası Havalimanı (MSP)"),
            new Location("ABD", "Missoula", "Missoula Uluslararası Havalimanı (MSO)"),
            new Location("ABD", "Mobile", "Mobile Bölgesel Havalimanı (MOB)"),
            new Location("İtalya", "Bari", "Bari/Palese Uluslararası Havalimanı (BRI)"),
            new Location("İtalya", "Bologna", "Bologna Guglielmo Marconi Havalimanı (BLQ)"),
            new Location("İtalya", "Cagliari", "Elmas Havalimanı (CAG)"),
            new Location("İtalya", "Cenova", "Cenova Cristoforo Colombo Havalimanı (GOA)"),
            new Location("İtalya", "Floransa", "Floransa Peretola Havalimanı (FLR)"),
            new Location("İtalya", "Katanya", "Katanya Fontanarossa Havalimanı (CTA)"),
            new Location("İtalya", "Milano", "Milano Bergamo Havalimanı (BGY)"),
            new Location("İtalya", "Milano", "Milano Malpensa Havalimanı (MXP)"),
            new Location("İtalya", "Milano", "Linate Havalimanı (LIN)"),
            new Location("İtalya", "Napoli", "Napoli Uluslararası Havalimanı (NAP)"),
            new Location("İtalya", "Olbia", "Costa Smeralda Havalimanı (OLB)"),
            new Location("İtalya", "Palermo", "Punta Raisi Havalimanı (PMO)"),
            new Location("İtalya", "Pisa", "Pisa Galileo Galilei Havalimanı (PSA)"),
            new Location("İtalya", "Roma", "Fiumicino – Leonardo da Vinci Havalimanı (FCO)"),
            new Location("İtalya", "Roma", "Ciampino Havalimanı (CIA)"),
            new Location("İtalya", "Torino", "Torino Havalimanı (TRN)"),
            new Location("İtalya", "Trieste", "TRIESTE (TRS)"),
            new Location("İtalya", "Venedik", "Venedik Marco Polo Havalimanı (VCE)"),
            new Location("Japonya", "Akita", "Akita Havalimanı (AXT)"),
            new Location("Japonya", "Amami", "Amami O Shima Havalimanı (ASJ)"),
            new Location("Japonya", "Aomori", "Aomori Havalimanı (AOJ)"),
            new Location("Japonya", "Asahikawa", "Asahikawa Havalimanı (AKJ)"),
            new Location("Japonya", "Fukuoka", "Fukuoka Havalimanı (FUK)"),
            new Location("Japonya", "Hakodate", "Hakodate Havalimanı (HKD)"),
            new Location("Japonya", "Hanamaki", "Hanamaki Havalimanı (HNA)"),
            new Location("Japonya", "Hiroşima", "Hiroşima Havalimanı (HIJ)"),
            new Location("Japonya", "Ishigaki", "New Ishigaki Havalimanı (ISG)"),
            new Location("Japonya", "Izumo", "Izumo Havalimanı (IZO)"),
            new Location("Rusya", "Nijnevartovsk", "Nijnevartovsk Havalimanı (NJC)"),
            new Location("Rusya", "Nizhny Novgorod", "Strigino Uluslararası Havalimanı (GOJ)"),
            new Location("Rusya", "Novosibirsk", "Novosibirsk Tolmachevo Havalimanı (OVB)"),
            new Location("Rusya", "Omsk", "Tsentralny Havalimanı (OMS)"),
            new Location("Rusya", "Perm", "Perm Bolshoye Savino Havalimanı (PEE)"),
            new Location("Rusya", "Rostov-na-Donu", "Rostov-na-Donu Uluslararası Havalimanı (ROV)"),
            new Location("Rusya", "Samara", "Samara Havalimanı (KUF)"),
            new Location("Rusya", "Sıktıvkar", "Syktyvkar Havalimanı (SCW)"),
            new Location("Rusya", "Soçi", "Adler-Sochi Uluslararası Havalimanı (AER)"),
            new Location("Rusya", "St. Petersburg", "St Petersburg Pulkovo Havalimanı (LED)"),
            new Location("Rusya", "Surgut", "Surgut Uluslararası Havalimanı (SGC)"),
            new Location("Rusya", "Şupaşkar", "Şupaşkar Uluslararası Havalimanı (CSY)"),
            new Location("Rusya", "Tomsk", "Tomsk Bogaşevo Havalimanı (TOF)"),
            new Location("Rusya", "Tümen", "Roşçino Uluslararası Havalimanı (TJM)"),
            new Location("Rusya", "Ufa", "Ufa Uluslararası Havalimanı (UFA)"),
            new Location("Rusya", "Ulyanovsk", "Vostoşni Havalimanı (ULY)"),
            new Location("Rusya", "Usinsk", "Usinsk Havalimanı (USK)"),
            new Location("Rusya", "Volgograd", "Volgograd Uluslararası Havalimanı (VOG)"),
            new Location("Rusya", "Voronej", "Chertovitskoye Havalimanı (VOZ)"),
            new Location("Rusya", "Yarçallı", "Begişevo Havalimanı (NBC)"),
            new Location("Rusya", "Yekaterinburg", "Yekaterinburg Koltsovo Havalimanı (SVX)"),
            new Location("Rusya", "Yoşkar-Ola", "Yoşkar Ola Havalimanı (JOK)"),
            new Location("Türkiye", "Adana", "Adana Havalimanı (ADA)"),
            new Location("Türkiye", "Adana", "Çukurova Havalimanı (COV)"),
            new Location("Türkiye", "Adıyaman", "Adıyaman Havalimanı (ADF)"),
            new Location("Türkiye", "Ağrı", "Ağrı Havalimanı (AJI)"),
            new Location("Türkiye", "Alanya", "Gazipaşa Alanya Havalimanı (GZP)"),
            new Location("Türkiye", "Amasya", "Amasya Merzifon Havalimanı (MZH)"),
            new Location("Türkiye", "Ankara", "Ankara Esenboğa Havalimanı (ESB)"),
            new Location("Türkiye", "Antalya", "Antalya Havalimanı (AYT)"),
            new Location("Türkiye", "Balıkesir - Edremit", "Koca Seyit Havalimanı (EDO)"),
            new Location("Türkiye", "Batman", "Batman Havalimanı (BAL)"),
            new Location("Türkiye", "Bingöl", "Bingöl Havalimanı (BGG)"),
            new Location("Türkiye", "Bursa", "Bursa Yenişehir Havalimanı (YEI)"),
            new Location("Türkiye", "Çanakkale", "Çanakkale Havalimanı (CKZ)"),
            new Location("Türkiye", "Denizli", "Denizli Çardak Havalimanı (DNZ)"),
            new Location("Türkiye", "Diyarbakır", "Diyarbakır Havalimanı (DIY)"),
            new Location("Türkiye", "Elazığ", "Elazığ Havalimanı (EZS)"),
            new Location("Türkiye", "Erzincan", "Erzincan Yıldırım Akbulut Havalimanı (ERC)"),
            new Location("Türkiye", "Erzurum", "Erzurum Havalimanı (ERZ)"),
            new Location("Türkiye", "Eskişehir", "Hasan Polatkan Havalimanı (AOE)"),
            new Location("Türkiye", "Gaziantep", "Gaziantep Havalimanı (GZT)"),
            new Location("Türkiye", "Hakkari", "Yüksekova Havalimanı (YKO)"),
            new Location("Türkiye", "Hatay", "Hatay Havalimanı (HTY)"),
            new Location("Türkiye", "Iğdır", "Iğdır Şehit Bülent Aydın Havalimanı (IGD)"),
            new Location("Türkiye", "Isparta", "Isparta Süleyman Demirel Havalimanı (ISE)"),
            new Location("Türkiye", "İstanbul", "İstanbul Havalimanı (IST)"),
            new Location("Türkiye", "İstanbul", "Sabiha Gökçen Havalimanı (SAW)"),
            new Location("Türkiye", "İzmir", "İzmir Adnan Menderes Havalimanı (ADB)"),
            new Location("Türkiye", "Kahramanmaraş", "Kahramanmaraş Havalimanı (KCM)"),
            new Location("Türkiye", "Kars", "Kars Harakani Havalimanı (KSY)"),
            new Location("Türkiye", "Kastamonu", "Kastamonu Havalimanı (KFS)"),
            new Location("Türkiye", "Kayseri", "Kayseri Havalimanı (ASR)"),
            new Location("Türkiye", "Kocaeli", "Kocaeli Cengiz Topel Havalimanı (KCO)"),
            new Location("Türkiye", "Konya", "Konya Havalimanı (KYA)"),
            new Location("Türkiye", "Kütahya", "Zafer Bölgesel Havalimanı (KZR)"),
            new Location("Türkiye", "Malatya", "Malatya Havalimanı (MLX)"),
            new Location("Türkiye", "Mardin", "Mardin Prof. Dr. Aziz Sancar Havalimanı (MQM)"),
            new Location("Türkiye", "Muğla-Bodrum", "Milas-Bodrum Havalimanı (BJV)"),
            new Location("Türkiye", "Muğla-Dalaman", "Dalaman Havalimanı (DLM)"),
            new Location("Türkiye", "Muş", "Muş Havalimanı (MSR)")
            new Location("Yunanistan", "Kastelorizo Island", "Kastelorizo Havalimanı (KZS)"),
            new Location("Yunanistan", "Kavala", "Kavala Havalimanı (KVA)"),
            new Location("Yunanistan", "Kefalonya", "Kefalonya Havalimanı (EFL)"),
            new Location("Yunanistan", "Kerpe Adası", "Karpathos Havalimanı (AOK)"),
            new Location("Yunanistan", "Kithira Island", "Kithira Havalimanı (KIT)"),
            new Location("Yunanistan", "Korfu", "Kerkyra Havalimanı (CFU)"),
            new Location("Yunanistan", "Kos", "Kos Havalimanı (KGS)"),
            new Location("Yunanistan", "Lemnos", "Limnos Havalimanı (LXS)"),
            new Location("Yunanistan", "Leros Island", "Leros Havalimanı (LRS)"),
            new Location("Yunanistan", "Midilli", "Midilli Havalimanı (MJT)"),
            new Location("Yunanistan", "Mikonos", "Mikonos Havalimanı (JMK)"),
            new Location("Yunanistan", "Milos Island", "Milos Havalimanı (MLO)"),
            new Location("Yunanistan", "Naxos Island", "Naxos Is Havalimanı (JNX)"),
            new Location("Yunanistan", "Paros Island", "Paros Havalimanı (PAS)"),
            new Location("Yunanistan", "Preveze/Lefkada", "Preveze/Lefkada Havalimanı (PVK)"),
            new Location("Yunanistan", "Rodos", "Rodos Havalimanı (RHO)"),
            new Location("Yunanistan", "Samos Island", "Samos Havalimanı (SMI)"),
            new Location("Yunanistan", "Santorini Island", "Santorini Havalimanı (JTR)"),
            new Location("Yunanistan", "Selanik", "Selanik Macedonia Havalimanı (SKG)"),
            new Location("Yunanistan", "Skiathos", "Skiathos Havalimanı (JSI)"),
            new Location("Yunanistan", "Skiros Island", "Skiros Havalimanı (SKU)"),
            new Location("Yunanistan", "Souda", "Ioannis Daskalogiannis Havalimanı (CHQ)"),
            new Location("Yunanistan", "Yanya", "Yanya Havalimanı (IOA)"),
            new Location("Yunanistan", "Zakinthos Island", "Zakinthos Island Havalimanı (ZTH)")
        };

        public static void fillCountries()
        {
            var countries = Locations.Select(obj => obj.Country).Distinct().ToList();
            MainForm.comboCountry.DataSource = countries;
        }

        public static void fillCities(string selectedCountry)
        {
            var cities = Locations.Where(obj => obj.Country == selectedCountry).Select(obj => obj.City).Distinct().ToList();
            MainForm.comboCity.DataSource = cities;
        }

        public static void fillAirports(string selectedCountry, string selectedCity)
        {
            var airports = Locations.Where(obj => obj.Country == selectedCountry && obj.City == selectedCity).Select(obj => obj.Airport).Distinct().ToList();
            MainForm.comboAirport.DataSource = airports;
        }
    }
}
