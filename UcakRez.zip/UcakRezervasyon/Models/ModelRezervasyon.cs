﻿# pragma warning disable

namespace UcakRezervasyon.Models
{
    public partial class ModelRezervasyon
    {
        public int IdRezervasyon { get; set; }
        public int UcakId { get; set; }
        public int LocationId { get; set; }
        public DateTime Date { get; set; }
        public string CustomerName { get; set; }
        public string CustomerSurname { get; set; }
        public string CustomerIDNo { get; set; }
        public string CustomerGender { get; set; }
        public int SeatNo { get; set; }

        internal void clearData()
        {
            throw new NotImplementedException();
        }

        internal void delete()
        {
            throw new NotImplementedException();
        }

        internal void save(ModelRezervasyon rezervasyon)
        {
            throw new NotImplementedException();
        }

        internal void update(ModelRezervasyon rezervasyon)
        {
            throw new NotImplementedException();
        }
    }
}
