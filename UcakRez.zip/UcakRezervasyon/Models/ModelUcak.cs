﻿# pragma warning disable

using System;

namespace UcakRezervasyon.Models
{
    public partial class ModelUcak
    {
        public int IdUcak { get; set; }
        public string UcakModel { get; set; }
        public string UcakBrand { get; set; }
        public string UcakSerialNo { get; set; }
        public int UcakSeatCapacity { get; set; }

        internal void clearData()
        {
            throw new NotImplementedException();
        }

        internal void delete()
        {
            throw new NotImplementedException();
        }

        internal void save(ModelUcak ucak)
        {
            throw new NotImplementedException();
        }

        internal void update(ModelUcak ucak)
        {
            throw new NotImplementedException();
        }
    }
}
